﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace library
{
    public class String
    {
        static string passkey = "Zn456LT";

        public bool First(bool a)
        {
            a = false;

            foreach (char d in passkey)
            {
                if (Char.IsLetter(d))
                    a = true;
            }

            return a;

        }

        public bool Second(bool a)
        {
            a = false;

            foreach (char d in passkey)
            {
                if (Char.IsDigit(d))
                    a = true;
            }

            return a;

        }

    

        public bool Third(bool a)
        {
            a = false;

            foreach (char d in passkey)
            {
                if (Char.IsUpper(d))
                    a = true;
            }

            return a;

        }

        public bool Fourth(bool a)
        {
            a = true;

            if (passkey.Length < 8)
                a = false;

            return a;

        }


    }
}























/*public bool Third(bool a)
    {
        a = true;

        foreach (char d in passkey)
        {
            string str = Convert.ToString(d);
            if (Regex.IsMatch(str, "^[А-Яа-я]+$"))
                a = false;
        }

        return a;

    }*/
